
def main(*args): 
    text = args[0]
    times = args[1]
    print(text*times)


m = main


m('txt ', 18)
