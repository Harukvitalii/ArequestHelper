Arequest Helper

to install use pip install arequests-helper

