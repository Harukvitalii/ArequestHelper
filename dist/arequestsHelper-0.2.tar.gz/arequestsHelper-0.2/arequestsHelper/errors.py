
line = '---'


errs = {
    
    'ERROR': line*3 + 'ERROR' + line*3, 
    'System ERROR': line*2 + 'System ERROR Connection closed' + line*2
    
}
